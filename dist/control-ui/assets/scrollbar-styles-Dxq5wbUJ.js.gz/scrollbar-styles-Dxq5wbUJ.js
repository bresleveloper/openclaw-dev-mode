import{n as e}from"./rolldown-runtime-8BhlS34s.js";import{Y as t,mt as n}from"./lit-runtime-DLvISeBM.js";var r;function i(){return(i=e((()=>{t(),r=n`
  * {
    scrollbar-width: thin;
  }

  ::-webkit-scrollbar {
    width: var(--scrollbar-size);
    height: var(--scrollbar-size);
  }

  ::-webkit-scrollbar-track,
  ::-webkit-scrollbar-corner {
    background: transparent;
  }

  ::-webkit-scrollbar-thumb {
    background: var(--scrollbar-thumb);
    background-clip: content-box;
    border: var(--scrollbar-thumb-inset) solid transparent;
    border-radius: var(--radius-full);
  }

  ::-webkit-scrollbar-thumb:hover,
  :hover::-webkit-scrollbar-thumb {
    background: var(--scrollbar-thumb-hover);
    background-clip: content-box;
  }
`})))()}export{r as n,i as t};
//# sourceMappingURL=scrollbar-styles-Dxq5wbUJ.js.map