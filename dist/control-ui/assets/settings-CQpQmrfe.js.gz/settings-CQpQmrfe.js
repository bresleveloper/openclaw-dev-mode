import{n as e}from"./rolldown-runtime-8BhlS34s.js";function t(){return(t=e((()=>{})))()}export{t};
//# sourceMappingURL=settings-CQpQmrfe.js.map